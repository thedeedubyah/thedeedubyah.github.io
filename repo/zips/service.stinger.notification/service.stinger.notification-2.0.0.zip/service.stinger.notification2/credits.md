Two images from [the Noun Project](http://thenounproject.com) are used in this add-on.

[Scorpio](https://thenounproject.com/term/scorpio/207235) by Michelle Abrahall

[Clapperboard](https://thenounproject.com/term/clapperboard/223935) by Noe Araujo
